<!-- saved from url=(0074)https://www.cs.hmc.edu/twiki/bin/view/CS5Fall2015/CS5GoldReviewExam1Point5 -->
<html><head><meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-15"></head><body class="composite"><p>

  
  <!--<base href="https://www.cs.hmc.edu/twiki/bin/view/CS5Fall2015/CS5GoldReviewExam1Point5">--><base href="."> 

  <title>CS5Fall2015 - CS5GoldReviewExam1Point5</title>


  <link rel="stylesheet" title="HMCCS5Skin" type="text/css" href="./CS5Fall2015 - CS5GoldReviewExam1Point5_files/hmccs5.css">
  <link rel="stylesheet" title="HMCCS5Skin" type="text/css" href="./CS5Fall2015 - CS5GoldReviewExam1Point5_files/hmccs5-colors-ltblue.css">
  <link rel="stylesheet" title="HMCCS5Skin" type="text/css" href="./CS5Fall2015 - CS5GoldReviewExam1Point5_files/hmccs5-colors-gold.css">
  <style type="text/css">
  .header {
	 background-image: url(https://www.cs.hmc.edu/~cs5grad/cs5/images/clouds.jpg);
  }
  //.sidebar {
  //  background-image: url(https://www.cs.hmc.edu/~cs5grad/cs5/images/clouds.jpg);
  //}
  .subheader {
	 background-image: url(https://www.cs.hmc.edu/~cs5grad/cs5/images/clouds.jpg);
  }
  .footer {
	 background-image: url(https://www.cs.hmc.edu/~cs5grad/cs5/images/clouds.jpg);
  }
  </style>

</p><p>

</p><p>
<a name="top"></a>
</p><p>
</p><div class="header">
  <img class="logo" src="./CS5Fall2015 - CS5GoldReviewExam1Point5_files/cs5_logo.png">
</div>
<p>
</p><p>
</p><div class="subheader">
  <a class="twikiLink" href="https://www.cs.hmc.edu/twiki/bin/view/CS5Fall2015/WebHome">CS5Fall2015 Web</a> &gt; 
  CS5GoldReviewExam1Point5
  <div style="margin-bottom: 6px;">
	 <b>Next HW</b>: &nbsp;&nbsp; <b><a class="twikiLink" href="https://www.cs.hmc.edu/twiki/bin/view/CS5Fall2015/Homework12Gold">Milestone/hw12</a></b> &nbsp;&nbsp; <b><a class="twikiLink" href="https://www.cs.hmc.edu/twiki/bin/view/CS5Fall2015/Homework12Black">Milestone/hw12</a></b>  <!-- <b><a class="twikiLink" href="/twiki/bin/view/CS5Fall2015/ProjectsPage">Final projects</a></b> and <a class="twikiLink" href="/twiki/bin/view/CS5Fall2015/Homework8Gold">HW 8</a></b>--> <!-- <b><a class="twikiLink" href="/twiki/bin/view/CS5Fall2015/Homework12Gold">Milestone/hw12</a></b> &nbsp;&nbsp; <b><a class="twikiLink" href="/twiki/bin/view/CS5Fall2015/Homework12Black">Milestone/hw12</a></b> --> <!-- <b><a class="twikiLink" href="/twiki/bin/view/CS5Fall2015/Homework11Gold">Gold HW 11</a></b>  <b><a class="twikiLink" href="/twiki/bin/view/CS5Fall2015/Homework11Gold">Gold hw 11</a></b> &nbsp;&nbsp; <b><a class="twikiLink" href="/twiki/bin/view/CS5Fall2015/Homework11Black">Black hw 11</a></b>    Homework12Gold  <a class="twikiLink" href="/twiki/bin/view/CS5Fall2015/ProjectsPage">ProjectsPage</a>  -->  &nbsp;&nbsp; will be due on: <font color="darkgreen"><b>Tue., Dec. 8, 11:59pm</b></font> <br>
	 Next Lab: <b><a class="twikiLink" href="https://www.cs.hmc.edu/twiki/bin/view/CS5Fall2015/Homework12Gold">Milestone/hw12 help</a></b>  <!-- <b><a class="twikiLink" href="/twiki/bin/view/CS5Fall2015/Lab11">Lab 11: vPython!</a></b>   <b><a class="twikiLink" href="/twiki/bin/view/CS5Fall2015/ProjectsPage">Final projects</a></b>  <b><a class="twikiLink" href="/twiki/bin/view/CS5Fall2015/Lab11">Lab 11: vPython!</a></b>   <b><a class="twikiLink" href="/twiki/bin/view/CS5Fall2015/Homework12Gold">Open lab: FSMs, ExCr, or projects</a></b>    --> &nbsp;&nbsp; will be held on: Tue./Wed., as grutoring hours in the CS labs - join us! <!-- Tue. Nov. 17 and Wed. Nov. 18 --> <br>
	 Submissions: <a href="http://www.cs.hmc.edu/submit">CS submission site</a>
  </div>
</div>
<p>
</p><div class="main">
<a name="text"></a><h2><a name="CS_5_Gold_Midterm_Exam_Review_20"></a> CS 5 Gold Midterm Exam Review 2015 </h2>
<p>
<!-- <ul>
<li> Set STYLECOLOR = gold
</li></ul> 
-->
</p><p>
</p><p>
<!--
<h3><a name="History_and_Context"></a> History and Context </h3> <ul>
<li> You should be prepared to answer questions from any of the readings.  We won't ask you super nit-picky details (like "In what year was Joseph Weizenbaum born?"), but you will need to be familiar with the articles to answer the questions.  For example, we might ask something like "The impact of Eliza worried Joseph Weizenbaum.  Why was he concerned?  Do you think his concerns were valid?  Why or why not?"
</li></ul> 
-->
</p><p>
</p><p>
The exam may cover any topic from lecture or from homework (through assignment 8) and up to, but NOT including, the lecture prior to the exam.
</p><p>
The best way to study for the exam is to think through (or redo) the in-class "quizzes" and the various hw problems <i>on paper</i>.  This is similar to the exam experience: largely forgiving of syntax and primarily focusing on ideas.   Jot down things you'd like to have at hand for the exam on the page of notes you may bring to the test.
</p><p>
<br>
</p><p>
<b> <a href="https://www.cs.hmc.edu/twiki/pub/CS5Fall2015/CS5GoldReviewExam1Point5/quizzes_to_midterm.pptx" target="_top">Here are all of the quizzes up to 10/28/15:  quizzes_to_midterm.pptx</a> </b>
</p><p>
</p><p>
<br>
</p><p>
Below are a list of topics in CS5 thus far. Further down are some practice problems you can try... .
</p><p>
<br>
</p><p>
</p><h2><a name="CS5_midterm_topics"></a> CS5 midterm topics </h2>
<p>
</p><h4><a name="Functions_from_class"></a> Functions from class </h4>
<p>
Just as a reminder, some of the useful functions from class include </p><ul>
<li> <tt>removeAll( e, L )</tt>- removes all <tt>e</tt>s from <tt>L</tt>
</li> <li> <tt>removeOne( e, L )</tt>- removes one <tt>e</tt> from <tt>L</tt>
</li> <li> <tt>removeUpto( e, L )</tt>- removes everything upto and including the first <tt>e</tt> from <tt>L</tt>
</li> <li> <tt>ind( e, L )</tt>- returns the index of <tt>e</tt> in <tt>L</tt> or, if not there, <tt>len(L)</tt>
</li> <li> <tt>count( e, L )</tt> - returns the number of <tt>e</tt>s in <tt>L</tt>
</li> <li> <tt>frontNum( L )</tt> - returns the number of repetitions of <tt>L[0]</tt> at the front of <tt>L</tt> (0 if <tt>L</tt> is empty)
</li> <li> <tt>binaryToNum( binstr )</tt> - returns the decimal value of the string <tt>binstr</tt>, which is a string of 0s and 1s
</li> <li> <tt>numToBinary( N )</tt> - returns the string of 0s and 1s that is the binary representation of the decimal value <tt>N</tt>
</li> <li> <tt>abs( x )</tt> - returns the absolute value of the (number) <tt>x</tt>
</li> <li> <tt>min( L )</tt> - returns the minimum element in the list <tt>L</tt>
</li> <li> <tt>max( L )</tt> - returns the maximum element in the list <tt>L</tt>
</li> <li> <tt>sort( L )</tt> - returns a sorted version of the the list <tt>L</tt>
</li></ul> 
<p>
You'll be able to use the functions on the exam without re-implementing them (unless a problem specifically prohibits one -- or specifically asks for its implementation...)
</p><p>
</p><h4><a name="Basics_of_Functional_Programming"></a> Basics of Functional Programming and Python </h4> <ul>
<li> Writing recursive functions
</li> <li> Working with lists and strings (slicing, indexing, etc)
</li> <li> Using list comprehensions <tt>LC</tt>
</li> <li> Lists of lists <tt>LoL</tt> and nested list comprehensions
</li> <li> Using the print statement for debugging
</li> <li> <code>print</code> vs. <code>return</code>
</li> <li> The exam <i><b>won't</b></i> ask about Picobot
</li></ul> 
<p>
</p><h4><a name="Problem_solving_and_algorithm_de"></a> Problem solving and algorithm development/use </h4> <ul>
<li> Breaking a problem down into functions
</li> <li> Specifying data representation/flow (i.e., specifying function inputs and outputs)
</li> <li> Caesar cipher algorithm (encipher and decipher)
</li></ul> 
<p>
</p><h4><a name="Representing_Data"></a> Representing Data </h4> <ul>
<li> Types of data (<code>int</code>, <code>str</code>, <code>float</code>, etc.), when to use each and converting between types
</li> <li> Representing characters (<code>chr</code> and <code>ord</code>), using ASCII-encoding (integers for characters)
</li> <li> Base conversion
</li> <li> Base-N arithmetic, etc.
</li></ul> 
<p>
</p><h4><a name="Circuits_and_Assembly"></a> Circuits and Assembly </h4> <ul>
<li> What the basic gates do (OR, AND, NOT)
</li> <li> How minterm expansion works (an OR of ANDs, each selecting one input)
</li> <li> How to use subcircuits (e.g., using the adders in the multiplier)
</li> <li> How to write simple looping programs in Hmmm, e.g., factorial, power, Fibonacci
</li> <li> The exam <i><b>won't</b></i> ask you to implement functions or recursion in Hmmm... .
</li></ul> 
<!-- <ul>
<li> What the stack is, what load and store do (officially, they're named <tt>storen</tt> and <tt>loadn</tt>), and why they're necessary for implementing functions in Hmmm.
</li></ul> 
-->
<p>
</p><p>
</p><h4><a name="Loops_and_iteration"></a> Loops and iteration </h4> <ul>
<li> How for loops and while loops work
</li> <li> How nested loops work
</li> <li> The pi-estimation problem
</li> <li> The TTY securities (statistical menu) problem
</li></ul> 
<p>
<br>
</p><p>
</p><h2><a name="Practice_Problems"></a> Practice Problems </h2>
<p>
Here are several practice problems to try as review.  You are also welcome to practice with the <a class="twikiLink" href="https://www.cs.hmc.edu/twiki/bin/view/CS5Fall2015/CS5BlackSampleExam1">CS 5 Black review problems</a>, <!--or <a class="twikiLink" href="/twiki/bin/view/CS5Fall2015/CS5BlackReviewExam2">CS 5 Black review problems, part 2</a>--> although if there's something we haven't covered, it won't be on the gold midterm!
</p><p>
</p><h4><a name="From_the_recursive_functional_po"></a> From the <i>recursive/functional</i> portion of CS 5 Gold: </h4>
<p>
The following seven functions are "exam-review" functions, just to remind you some of the things you have used thus far this term:
</p><ul>
<li> Write a function <tt>countOnes( S )</tt> that takes in a string <tt>S</tt> of <tt>'0'</tt>s and <tt>'1'</tt>s and returns the number of <tt>'1'</tt>s in the input.
</li>
<li> Write a function <tt>swapBits( S )</tt> that takes in a string <tt>S</tt> of <tt>'0'</tt>s and <tt>'1'</tt>s and returns a string in which each bit in <tt>S</tt> has been swapped with the other bit. For example, <tt>swapBits('101011')</tt> would return <tt>'010100'</tt>. 
</li>
<li> Write a function <tt>numDivisors( N )</tt>that returns the number of integers from <tt>1</tt> to <tt>N</tt> (inclusive) that divide <tt>N</tt> evenly. For example, <tt>numDivisors(42)</tt> would return <tt>8</tt>, since 1, 2, 3, 6, 7, 14, 21, and 42 are divisors.
</li>
<li> Use the above <tt>numDivisors( N )</tt> function in order to write a function <tt>mostDivisors( L )</tt> that takes in a list of integers and returns the integer with the most divisors. For instance,
<tt>mostDivisors( [2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14] )</tt> would return <tt>12</tt>.
</li>
<li> Write a function <tt>countTransitions( S )</tt> that takes in a string <tt>S</tt> of <tt>'0'</tt>s and <tt>'1'</tt>s and returns the number of times there is a transition from a <tt>'0'</tt> to a <tt>'1'</tt> or vice-versa in that input string.  For example, <tt> countTransitions('1110110000')</tt> would return <tt>3</tt>. 
</li>
<li> Write a function <tt>longestString( L )</tt> that takes in a list of strings as input and returns the longest string from that list, e.g., <tt>longestString( [ 'short', 'longer', 'sesquipedalian' ] )</tt> would return <tt>'sesquipedalian'</tt>.
</li>
<li> Write a function <tt>cycle( S, n )</tt> that takes in a string <tt>S</tt> of <tt>'0'</tt>s and <tt>'1'</tt>s and an integer <tt>n</tt> and returns the a string in which <tt>S</tt> has shifted its last character to the initial position <tt>n</tt> times. For example, <tt>cycle('1110110000', 2)</tt> would return <tt>'0011101100'</tt>. 
</li>
</ul>
<p>
<br>
</p><p>
</p><p>
</p><h4><a name="Digital_Logic_practice"></a> Digital Logic practice </h4>
<p>
Given a description, you should be able to create a truth table, and then use the minterm expansion principle to write and equation and draw a circuit to implement that function.  For example, you might get the following problem:
</p><p> </p><ul>
<li> Design a truth table, minterm formula, and circuit that will implement a 2-bit greater-than function.  Your function should take 4 bits of input, x<sub>1</sub>, x<sub>0</sub>, y<sub>1</sub> and y<sub>0</sub> and return true if the two-bit number x<sub>1</sub>x<sub>0</sub> is greater than the two-bit number y<sub>1</sub>y<sub>0</sub>.
</li></ul> 
<p> </p><ul>
<li> Now, imagine that you had many of the 2-bit greater-than circuit components (as specified in the previous section) -- how could you compose a number of them together to immplement a four-bit greater-than circuit. A four-bit greater-than circuit would take in two four-bit inputs x<sub>3</sub>x<sub>2</sub>x<sub>1</sub>x<sub>0</sub> and y<sub>3</sub>y<sub>2</sub>y<sub>1</sub>y<sub>0</sub> and return true if the former is greater than the latter.
</li></ul> 
<p>
</p><p>
<br>
</p><p>
</p><h4><a name="Hmmm_practice"></a> Hmmm practice </h4>
<p>
We will provide a page with the full Hmmm reference - that is, all of the instructions - at the back of the exam.
</p><p>
Example #1: Write a looping Hmmm program that reads in positive integers from the user.  </p><ul>
<li> The program should accumulate (add) the sum of those integers until a zero is input. 
</li> <li> Then, the program should print out both the sum and the average before halting
</li></ul> 
<p>
Example #2: 
We might provide a Hmmm program and ask what it computes. 
</p><p>
<!--
You will <i>not</i> need to implement functions/recursion in Hmmm on the midterm exam (<i><b>reading</b></i> code like the functional factorial example would be OK, however).
-->
</p><p>
<!--
If we were to give you this problem, we would also provide the factorial or power function, implemented in Hmmm, as a starting point.
Consider the python program below:
<p />
<pre><code>
   def main()
      read X  # This is not real python syntax, 
                   # but imagine that it reads X from the user
      read Y   # again...
      foo(X, Y)

   def foo(X, Y):
     if X == 0: return 1
     else:
       A = foo(X-1, Y*2)
       Result = A + X + Y
       return Result
</pre></code>
<p />
Translate this program faithfully to Hmmm, including the function calls made.
<p />
Keep the standard conventions we used in class: <ul>
<li> arguments are passed in registers <code>r1</code> and <code>r2</code>
</li> <li> the return value is held in register <code>r13</code>
</li> <li> the return address is stored in <code>r14</code>
</li> <li> and the stack pointer is in <code>r15</code> 
</li></ul> 
-->
</p><p>
<!--
You should also be prepared to answer questions like "what is the largest number of stack locations used by this Hmmm program, main(), when run on the input 2?".
-->
</p><p>
<br>
</p><p>
</p><h4><a name="Loops_practice"></a> Loops practice </h4>
<p>
You should be familiar with <code>for</code> loops and <code>while</code> loops and the <code>break</code> command for "escaping" from them. Also, you should
feel comfortable with using a conditional ( <code>if</code> ) within a loop and nested loops (loops-within-loops). 
For example, you should feel comfortable writing these examples, as well as the ones we covered in class and on
assignments:
</p><p>
Example #1: Write a function index_nearest_42( L ) that takes in a list of numbers, <tt>L</tt>  and returns the <em>index</em> of the element whose value is closest to 42. 
</p><p>
Example #2: Write a function longestDNA( s ) that takes in a string from the user (or, perhaps, from the text of a file). Then, it looks within that input string for the longest substring that consists only of the characters 'A', 'C', 'G', and 'T'. Ties may be broken arbitrarily. For example, 
</p><p>
</p><pre>longestDNA( 'ACCGXXCXXGTTACTGGGCXTTGT' ) would return 'GTTACTGGGC'
</pre>
<p>
Example #3: Write a function mostCommonPair( s ) that takes in a string <tt>s</tt> and returns the two-character string that appears most often as a substring within <tt>s</tt>. 
</p><p>
<!-- This problem would be a natural one in which to use dictionaries, for example. -->
</p><p>
<!--
<p />
<h4><a name="Dictionaries"></a> Dictionaries </h4>
<p />
Example #1: Consider a python dictionary whose keys are words and whose associated values are the definitions of those words as in:
<pre>
D = {"zebra": "a striped animal", "aardvark" : "an animal that likes to eat ants", "skunk" : "a striped animal"}
</pre>
<p />
Write a function called <code>reverseLookup</code> that takes as input two arguments:  a dictionary and a definition string.  The function then returns the list of all keys that 
have that definition.  In the example above, if we passed in the dictionary <code>D</code> and the string <code>"a striped animal"</code> we would get back a list containing "zebra" and "skunk": <tt>["zebra", "skunk"]</tt>  Recall that the dictionary type has a <code>keys()</code> method that returns the list of keys in the dictionary.
<p />
Example #2: Write a Python function <tt>valueOrder( D )</tt> that prints out the keys and entries in a Python dictionary whose values are strings -- <i>in the order of their values</i>.
For example, suppose that <tt>D = { "a_key": "lion", "b_key": "zebra", "c_key": "antelope" }</tt>. Then <tt>valueOrder( D )</tt> should print the following:
<pre>
key: c&#95;key, value: antelope
key: a&#95;key, value: lion
key: b&#95;key, value: zebra
</pre>
<p />
<p />
<h4><a name="Classes"></a> Classes </h4>
<p />
Write a class called <code>Mudder</code> that has the following methods:
<p /> <ul>
<li>  The <code>__init__</code> constructor has three  arguments, <code>firstName</code>, <code>lastName</code>, and <code>dorm</code>.  If someone with that name already exists, this is OK, but a warning message is printed indicating that a Mudder with that name has already been created.
</li> <li>  The <code>addFriend</code> method takes one argument, a reference to a <code>Mudder</code>, and adds that friend to the list of friends.
</li> <li>  The <code>__repr__</code> method takes on arguments and returns a string that contains the full name of the person.
</li> <li>  The <code>myFriends</code> method takes no arguments and returns a list of Mudder objects who are that persons friends.
</li> <li>  The <code>myNetwork</code> method takes no arguments and returns a list of Mudder objects that are that persons friends, or friends of that persons friends, etc.  (Warning:  This method will have problems if friendship is mutual or there is any cycle of friends.  Why?)
</li></ul> 
<p />
<p />
<p />
<h4><a name="Data_mutation"></a> Data mutation </h4>
<p />
Similar to the examples in class, you might be asked to trace how data mutates as code is executed.   For example, we might ask you:
<p />
What are the values of each of the day, month and year field in d1, d2 and d3 when this code finishes
<code><pre>
[In a .py file]
def dateFun( d1, d2 ):
    if d1 == d2:
        d1.tomorrow()
    if d1.equals(d2):
        d2.tomorrow()
    return d1

>>> d1 = Date(1, 1, 2008)
>>> d2 = Date(1, 1, 2008)
>>> d3 = d2
>>> d4 = dateFun(d1, d2)
>>> dateFun(d2, d4)
</pre></code>
<p />
--><a name="bottom"></a>
</p></div>
<p>
</p><div class="footer">
<p>
</p></div>
<p>

</p></body></html>